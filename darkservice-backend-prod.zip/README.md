
# DarkService Backend

## Environment variables
BOT_TOKEN=
ADMIN_CHAT_ID=
MONGO_URI=

## Start
npm install
npm start
