
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import fetch from "node-fetch";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Health check
app.get("/health", (req, res) => res.send("OK"));

// MongoDB
mongoose.connect(process.env.MONGO_URI);

// Models
const Ticket = mongoose.model("Ticket", new mongoose.Schema({
  name: String,
  phone: String,
  device: String,
  description: String,
  createdAt: { type: Date, default: Date.now }
}));

const Review = mongoose.model("Review", new mongoose.Schema({
  name: String,
  rating: Number,
  text: String,
  approved: { type: Boolean, default: false }
}));

// Telegram notify
async function notify(text) {
  const url = `https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`;
  await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: process.env.ADMIN_CHAT_ID,
      text
    })
  });
}

// Routes
app.post("/api/ticket", async (req, res) => {
  const ticket = await Ticket.create(req.body);
  await notify(`🛠 Новая заявка\nИмя: ${ticket.name}\nТелефон: ${ticket.phone}`);
  res.json({ ok: true });
});

app.post("/api/review", async (req, res) => {
  await Review.create(req.body);
  await notify("⭐ Новый отзыв (на модерации)");
  res.json({ ok: true });
});

app.get("/api/reviews", async (req, res) => {
  const reviews = await Review.find({ approved: true });
  res.json(reviews);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log("Backend started on", PORT));
